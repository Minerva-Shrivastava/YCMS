package com.yash.ldap.config;

import java.util.Hashtable;
import javax.naming.Context;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

public class IntializeHashTableEnvironmentVariablesForContext {

	Hashtable<String, Object> environment;
	
//	@Value("${LDAP_INITIAL_CONTEXT_FACTORY}")
	private String LDAP_INITIAL_CONTEXT_FACTORY/**"com.sun.jndi.ldap.LdapCtxFactory"**/;
	
//	@Value("${LDAP_SECURITY_AUTHENTICATION}")
	private String LDAP_SECURITY_AUTHENTICATION/**"simple"**/ ;
	
//	@Value("${LDAP_PROVIDER_URL}")
	private String LDAP_PROVIDER_URL/**"ldap://inidradc01.yash.com/"**/ ;
	
//	@Value("${LDAP_SEARCH_BASE}")
	private String LDAP_SEARCH_BASE/**"DC=yash,DC=com"**/  ;
	
	
	
	public IntializeHashTableEnvironmentVariablesForContext() {
		System.out.println("from intializer"+LDAP_INITIAL_CONTEXT_FACTORY+" "+LDAP_PROVIDER_URL );
	}

	


	public IntializeHashTableEnvironmentVariablesForContext(String lDAP_INITIAL_CONTEXT_FACTORY,
			String lDAP_SECURITY_AUTHENTICATION, String lDAP_PROVIDER_URL, String lDAP_SEARCH_BASE) {
		super();
		LDAP_INITIAL_CONTEXT_FACTORY = lDAP_INITIAL_CONTEXT_FACTORY;
		LDAP_SECURITY_AUTHENTICATION = lDAP_SECURITY_AUTHENTICATION;
		LDAP_PROVIDER_URL = lDAP_PROVIDER_URL;
		LDAP_SEARCH_BASE = lDAP_SEARCH_BASE;
	}




	public Hashtable<String, Object> intializeHashTableVariables(String email, String password) {
		environment = new Hashtable<>();
		environment.put(Context.SECURITY_AUTHENTICATION,LDAP_SECURITY_AUTHENTICATION);
		environment.put(Context.INITIAL_CONTEXT_FACTORY,LDAP_INITIAL_CONTEXT_FACTORY);
		environment.put(Context.PROVIDER_URL, LDAP_PROVIDER_URL);
		environment.put(Context.SECURITY_PRINCIPAL, email);//username
		environment.put(Context.SECURITY_CREDENTIALS, password);//passowrd
		environment.put("java.naming.ldap.attributes.binary", "objectSID");
		System.out.println("hdujhfodajuoi");
		return environment;

	}



	public Hashtable<String, Object> getEnvironment() {
		return environment;
	}



	public void setEnvironment(Hashtable<String, Object> environment) {
		this.environment = environment;
	}


	public String getLDAP_SEARCH_BASE() {
		return LDAP_SEARCH_BASE;
	}

}
