package com.yash.ldap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.yash.ldap.config.IntializeHashTableEnvironmentVariablesForContext;

@SpringBootApplication
public class LdapApplication {

	
	@Value("${LDAP_INITIAL_CONTEXT_FACTORY}")
	private String LDAP_INITIAL_CONTEXT_FACTORY/**"com.sun.jndi.ldap.LdapCtxFactory"**/;
	
	@Value("${LDAP_SECURITY_AUTHENTICATION}")
	private String LDAP_SECURITY_AUTHENTICATION/**"simple"**/ ;
	
	@Value("${LDAP_PROVIDER_URL}")
	private String LDAP_PROVIDER_URL/**"ldap://inidradc01.yash.com/"**/ ;
	
	@Value("${LDAP_SEARCH_BASE}")
	private String LDAP_SEARCH_BASE/**"DC=yash,DC=com"**/  ;
	
	
	@Bean
	public IntializeHashTableEnvironmentVariablesForContext initializeHashTableEnv()
	{
		System.out.println(LDAP_INITIAL_CONTEXT_FACTORY+"  "+LDAP_PROVIDER_URL);
		return new IntializeHashTableEnvironmentVariablesForContext(LDAP_INITIAL_CONTEXT_FACTORY
				,LDAP_SECURITY_AUTHENTICATION,LDAP_PROVIDER_URL,LDAP_SEARCH_BASE);
		
	}
	public static void main(String[] args) {
		SpringApplication.run(LdapApplication.class, args);
		
	
		
		
	}
}
