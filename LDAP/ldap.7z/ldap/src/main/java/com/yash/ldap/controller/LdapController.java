package com.yash.ldap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ldap.dao.UserDAO;
import com.yash.ldap.model.User;

@RestController
@RequestMapping("/")
public class LdapController {
	
	@Autowired
	UserDAO userdao;	
	
	
	@RequestMapping(value="/auth",method=RequestMethod.POST)
	public boolean authenticateUser(@RequestBody User user)
	{
		
		return userdao.authenticateUser(user.getEmail(), user.getPassword());
	}
}
