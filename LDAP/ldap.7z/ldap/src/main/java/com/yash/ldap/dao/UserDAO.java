package com.yash.ldap.dao;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.ldap.config.IntializeHashTableEnvironmentVariablesForContext;

@Repository
public class UserDAO {
	
	private SearchResult searchResult;
	@Autowired
	IntializeHashTableEnvironmentVariablesForContext icontext; /**=new IntializeHashTableEnvironmentVariablesForContext();**/
	
	String accountToLookup;
	Map<Object, List<Object>> mapofAttributesWithValues;
	
	public boolean authenticateUser(String email,String password){
	
		Hashtable<String, Object> environment = icontext.intializeHashTableVariables(email, password);
		accountToLookup = "sAMAccountName=" + email.substring(0, email.indexOf("@"));
		InitialDirContext ctx = null;
		try {
			ctx = new InitialDirContext(environment);
			SearchControls searchControls = new SearchControls();
			searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			NamingEnumeration<SearchResult> results = ctx.search(icontext.getLDAP_SEARCH_BASE(), accountToLookup,
					searchControls);
			//LDAP_SEARCH_BASE :Domain (com.yash), accountToLookup=prashant.chauhan,searchControls=
			if (results.hasMoreElements()) {
				searchResult = results.nextElement();
				return true;
			}
			ctx.close();
		} catch (NamingException e) {
			
		}
		return false;

		
		
	
		
	}
	
}
