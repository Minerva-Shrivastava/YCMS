package com.yash.ycmscore.dao;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.ycmscore.model.Customer;

public class CustomerDAOTest {
	
	@Mock
	CustomerDAO customerDAO;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void test_insert_method_with_actual_customer_object_return1_on_success() {

		Customer customer= new Customer();
		when(customerDAO.insert(any(Customer.class))).thenReturn(1);
		assertThat(customerDAO.insert(customer),is(1));

	}
	
	@Test
	public void test_insert_method_with_actual_customer_object_return0_on_failure() {

		Customer customer= new Customer();
		when(customerDAO.insert(any(Customer.class))).thenReturn(0);
		assertThat(customerDAO.insert(customer),is(0));

	}
}
