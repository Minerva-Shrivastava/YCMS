package com.yash.ycmscore.service;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.naming.AuthenticationException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.serviceimpl.CustomerServiceImpl;

public class CustomerServiceTest {
	
	@Mock
	CustomerServiceImpl serviceImpl;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void test_customerRegistration_method_with_actual_customer_object_return_on_success() {

		Customer customer= new Customer();
		when(serviceImpl.customerRegistration(any(Customer.class))).thenReturn("Registration Successful");
		assertThat(serviceImpl.customerRegistration(customer),is("Registration Successful"));

	}
	
	@Test
	public void test_customerRegistration_method_with_actual_customer_object_return_on_authentication_fail() {

		Customer customer= new Customer();
		when(serviceImpl.customerRegistration(any(Customer.class))).thenReturn("Email Or Password is incorrect");
		assertThat(serviceImpl.customerRegistration(customer),is("Email Or Password is incorrect"));

	}
	
	@Test
	public void test_customerRegistration_method_with_actual_customer_object_return_on_already_existing_Customer() {

		Customer customer= new Customer();
		when(serviceImpl.customerRegistration(any(Customer.class))).thenReturn("Customer is Already Registered to YCMS");
		assertThat(serviceImpl.customerRegistration(customer),is("Customer is Already Registered to YCMS"));

	}
	
	@Test(expected=AuthenticationException.class)
	public void test_customerRegistration_method_with_actual_customer_object_return_on_LDAPAuthenticationFailure() {

		Customer customer= new Customer();
		doThrow(AuthenticationException.class).when(serviceImpl).customerRegistration(customer);
		serviceImpl.customerRegistration(customer);

	}
	
	@Test
	public void test_getListOfDomainName_method() {
		List<String> domainNames= new ArrayList<String>();
		when(serviceImpl.getListOfDomainName()).thenReturn(domainNames);
		assertThat(serviceImpl.getListOfDomainName(),is(notNullValue()));

	}
	
}
