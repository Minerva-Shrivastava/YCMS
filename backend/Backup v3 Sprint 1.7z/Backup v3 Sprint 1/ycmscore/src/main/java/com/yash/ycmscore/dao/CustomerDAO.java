package com.yash.ycmscore.dao;

import java.util.List;

import com.yash.ycmscore.model.Customer;

/**
 * this interface will have methods for handling customer related operations
 * such as creating a database for the customer
 * 
 * Date - 04/04/2018
 * 
 * @author ishan.juneja Functionalities provided:- 1.) insert a user 2.) create
 *         new database using domainName 3.) list all the databases
 *
 */
public interface CustomerDAO {

	/**
	 * this method will create a database with the name passed to it
	 * 
	 * @author ishan.juneja
	 * @param dbname
	 */
	public void createDatabase(String dbname);

	/**
	 * this method will return all dbnames
	 * 
	 * @author ishan.juneja
	 * @return list of all database names in mysql server
	 */
	public List<String> getAllDatabaseNames();

	/**
	 * this method will insert a new customer in the database which is passed to
	 * it
	 *
	 * @author chetan.magre
	 * @param customer
	 *            object will have details of new customer
	 * @return int value on successful or unsuccessful operation
	 */
	public int insert(Customer customer);

	/**
	 * this method will check that customer trying to register is new or
	 * Registered
	 * 
	 * @author chetan.magre
	 * @param email
	 *            email of current customer trying to register
	 * @return boolean value on basis of is customer already exist or not
	 */
	public Customer isCustomerExist(String email);
}
