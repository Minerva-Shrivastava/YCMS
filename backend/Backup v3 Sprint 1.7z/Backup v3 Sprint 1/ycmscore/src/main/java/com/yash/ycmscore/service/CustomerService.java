package com.yash.ycmscore.service;

import java.util.List;

import com.yash.ycmscore.model.Customer;

/**
 * this is the service interface for Customer related operations such as create,
 * list customers, update and delete a Customer
 * 
 * Date - 07/04/2018
 * 
 * @author chetan.magre Functionalities provided 1.) Customer Registration 2.)
 *         getting list of all database
 * 
 */
public interface CustomerService {
	
	/**
	 * this method will register a new customer
	 * 
	 * @author chetan.magre
	 * @param customer
	 * @return String value for successful and unsuccessful registration
	 */
	public String customerRegistration(Customer customer);
	
	/**
	 * this method will list all the domainNames
	 * 
	 * @author chetan.magre
	 * @return list of domianNames
	 */
	public List<String> getListOfDomainName();

	
	/**
	 * This method will authenticate the customer based on the credentials provided
	 * 
	 * @param Yash emailId of customer
	 * @param Yash password of customer
	 * @return true if customer is authenticated otherwise false
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean customerAuthentication(String email, String password);
	
	
}
