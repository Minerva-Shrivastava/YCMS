package com.yash.ycmscore.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ycmscore.dao.CustomerDAO;
import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.service.CustomerService;

/**
 * this is the implementation of the CustomerService interface
 * 
 * Date - 07/04/2018
 * 
 * @author chetan.magre
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 */
@Service
public class CustomerServiceImpl implements CustomerService {
	/**
	 * this is the customerDAO bean needed in service
	 * 
	 * @author chetan.magre
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private CustomerDAO customerDAO;

	/**
	 * this is the LDAPService bean needed in service to use external LDAP
	 * service
	 * 
	 * @author chetan.magre
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private LDAPService ldapService;
	/**
	 * this is the MailService bean needed in service use external mail service
	 * 
	 * @author chetan.magre
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private MailService mailService;

	/**
	 * url that is used by getURL() method.
	 * 
	 * @author saloni.jain
	 */
	private final String URL = "http://localhost:4200/";

	/**
	 * this method will check whether the customer is registered or not and if
	 * not it will register user and will allot domain name as provided
	 * 
	 * @author chetan.magre
	 * @param customer
	 *            object with detail as email password and domain Name
	 * @return String value based on successful registration or not
	 */
	public String customerRegistration(Customer customer) {

		Customer isExist = customerDAO.isCustomerExist(customer.getEmail());
		if (isExist != null) {
				System.out.println("customer exists");
			return "Customer is Already Registered to YCMS";
		} else {
			boolean status = ldapService.userAuthentication(customer.getEmail(), customer.getPassword());
			if (status) {
				List<Object> detail = null;
				Map<Object, List<Object>> customerDetails = ldapService.getAuthenticatedUserDetails();
				detail = customerDetails.get("givenName");
				customer.setName((String) detail.get(0));
				detail = customerDetails.get("sn");
				customer.setSurname((String) detail.get(0));
				customerDAO.insert(customer);
				customerDAO.createDatabase(customer.getDomainName());
				mailService.sendEmail(customer.getEmail(), customer.getDomainName(), getURL("signin"));

				String path = System.getProperty("catalina.base") + "\\webapps\\" + customer.getDomainName();
				System.out.println("PATH : " + path);
				File file = new File(path);
				file.mkdir();

				File index = new File(file.getAbsolutePath() + "\\index.html");
				try {
					index.createNewFile();

				} catch (IOException e) {
					e.printStackTrace();
				}

				return "Registration Successful";
			} else {
				return "Email Or Password is incorrect";
			}
		}
	}

	/**
	 * this method will get list of all domainName in the database and return
	 * 
	 * @author chetan.magre
	 * @return list of all domainNames
	 */
	public List<String> getListOfDomainName() {
		return customerDAO.getAllDatabaseNames();
	}

	/**
	 * this is a generic method that will return link based on action i.e.(name
	 * of form) for which we want to create a link and this link will be used as
	 * to navigate on different pages.
	 * 
	 * @author saloni.jain
	 * @param action
	 *            is the argument i.e.(name of form) for which we want to create
	 *            a link
	 * @return url based on action
	 */
	private String getURL(String action) {

		return URL + action;
	}

	/**
	 * This method will authenticate the customer based on the credentials provided 
	 * by calling the LDAPService for LDAP authentication services
	 * 
	 * @param Yash emailId of customer
	 * @param Yash password of customer
	 * @return true if customer is authenticated otherwise false
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean customerAuthentication(String email, String password) {
		return ldapService.userAuthentication(email, password);
	}

}
