package com.yash.ycmscore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * this is the user POJO. this will be used as a data traveler between the
 * different layers of the application this will also work as an entity for
 * database(customers)
 * 
 * Date - 07/04/2018
 * 
 * @author chetan.magre
 * @Entity Every persistent POJO class is an entity and is declared using
 *         the @Entity annotation
 * @Table annotation allows you to specify the details of the table that will be
 *        used to persist the entity in the database.
 */
@Entity
@Table(name = "customers")
public class Customer {
	/**
	 * this will be the id of the current customer
	 * 
	 * @Id declares the identifier property of this entity
	 * @GeneratedValue can be used to define the identifier generation strategy
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	/**
	 * this will be the name of the current customer
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "name")
	private String name;

	/**
	 * this will be the surname of the current customer
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "surname")
	private String surname;

	/**
	 * this will be the email of the current customer
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "email")
	private String email;

	/**
	 * this will be the domainName of the current customer
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "domainName")
	private String domainName;
	/**
	 * this will be the password of the current customer which will not be saved
	 * in to database
	 * 
	 * @Transient This is used when you don’t want to persist the value in database.
	 */
	@Transient
	private String password;

	/**
	 * a default constructor for Customer class.
	 */
	public Customer() {

	}

	/**
	 * a parameterized constructor required for the conversion to JSON
	 */
	public Customer(int id, String name, String surname, String email, String domainName, String password) {
		super();
		this.id = id;
		this.name = name;
		this.surname = surname;
		this.email = email;
		this.domainName = domainName;
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
