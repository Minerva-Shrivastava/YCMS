package com.yash.ycmsweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ycmscore.exception.InvalidCredential;
import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.service.CustomerService;

/**
 * this is the Controller that will handle the requests for the Customer related
 * resources
 * 
 * Date - 04/04/2018
 * 
 * @author ishan.juneja
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {
	/**
	 * this will be the bean, which will give the methods of CustomerService to
	 * the controller
	 * 
	 * @author chetan.magre
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private CustomerService customerService;

	/**
	 * this method will return db not available if a database with the name
	 * provided is present in the mysql server
	 * 
	 * @author ishan.juneja
	 * @param dbname
	 * @return 'available' if the name is available or 'domain not available' if
	 *         dbname exists
	 */
	@RequestMapping(value = "/customers/getdb/{dbname}", method = RequestMethod.GET)
	@ResponseBody
	public String getDBAvailablity(@PathVariable String dbname) {

		List<String> dbnames = customerService.getListOfDomainName();
		for (String tempdbname : dbnames) {
			if (dbname.equals(tempdbname)) {
				return "domain Not Available";
			}
		}
		return "available";
	}

	/**
	 * this method will get customer registration details such as email password
	 * domainName and will return proper String message to acknowledge customer
	 * 
	 * @author chetan.magre
	 * @param customer
	 *            object obtained in the form of json which is mapped to
	 *            customer Object
	 * @return String Message according to customer registration like
	 *         Registration successful, Email or Password is Incorrect, Customer
	 *         Already Registered
	 */
	@RequestMapping(value = "/customers/register", method = RequestMethod.POST)
	@ResponseBody
	public String customerRegisteration(@RequestBody Customer customer) {
		return customerService.customerRegistration(customer);
	}
	
	/**
	 * This method will authenticate the customer based on the credentials provided.
	 * 
	 * @param customer JSON object having the credentials
	 * @return true if customer is authenticated otherwise false
	 * 
	 * @author minerva.shrivastava
	 */
	@RequestMapping(value="/customers/authenticate",method=RequestMethod.POST)
	public boolean authenticateUser(@RequestBody Customer customer,HttpServletResponse httpServletResponse)
	{	
		if(customerService.customerAuthentication(customer.getEmail(),customer.getPassword())){
			return true;
			
		}
		else {
			httpServletResponse.setHeader("Authorization", null);
			throw new InvalidCredential("invalid username or password");
			}
		
	}

}
