package com.yash.ycmsweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ycmscore.dao.CustomerDAO;

/**
 * this is the Controller that will handle the requests for the Customer related
 * resources
 * 
 * @author ishan.juneja
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {

	// temporary customerdao bean. Make service interface and its implementation in between
	@Autowired
	private CustomerDAO customerDAO;

	/**
	 * this method will return db not available 
	 * if a database with the name provided is present
	 * in the mysql server
	 * 
	 * @author ishan.juneja
	 * @param dbname
	 * @return 'available' if the name is available or 'not available' if dbname exists
	 */
	@RequestMapping(value = "/customers/getdb", method = RequestMethod.GET)
	@ResponseBody
	public String getDBAvailablity(@RequestParam String dbname) {

		List<String> dbnames = customerDAO.getAllDatabaseNames();
		for (String tempdbname : dbnames) {
			if (dbname.equals(tempdbname)) {
				return "db exists";
			}
		}
		return "available";
	}
	
	@RequestMapping(value="/customers/createdb",method=RequestMethod.POST)
	public void createDB(@RequestParam String dbname){
		customerDAO.createDatabase(dbname);
	}

}
