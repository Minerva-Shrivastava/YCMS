package com.yash.ycmscore.dao;

import java.util.List;

/**
 * this interface will have methods for handling customer related operations
 * such as creating a database for the customer
 * 
 * @author ishan.juneja
 *
 */
public interface CustomerDAO {

	/**
	 * this method will create a database with the name passed to it
	 * 
	 * @author ishan.juneja
	 * @param dbname
	 */
	public void createDatabase(String dbname);

	/**
	 * this method will return all dbnames
	 * 
	 * @author ishan.juneja
	 * @return list of all database names in mysql server
	 */
	public List<String> getAllDatabaseNames();
}
