package com.yash.ycmscore.daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.ycmscore.dao.CustomerDAO;

@Repository
public class CustomerDAOImpl implements CustomerDAO {

	/**
	 * Connection reference to be used in the methods of the class
	 */
	Connection con;
	
	/**
	 * Constructor to initialize connection object
	 * 
	 * @author ishan.juneja
	 * 
	 */
	public CustomerDAOImpl() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(  
						"jdbc:mysql://yi1007118dt:3306/","ycms","ycms");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}  
		
	}
	
	/**
	 * this method will create a database with the name provided to it
	 * 
	 * @author ishan.juneja
	 * @param name of the db to be created
	 */
	public void createDatabase(String dbname) {
		
		try{  
			
			  
			Statement stmt=con.createStatement();  
			stmt.executeUpdate("create database "+dbname);  
			}catch(Exception e){ System.out.println(e);}  
		
	}

	/**
	 * this method will return all dbnames
	 * 
	 * @author ishan.juneja
	 * @return list of all database names in mysql server
	 */
	public List<String> getAllDatabaseNames() {
		List<String> dbnames=new ArrayList<String>();
		try {
			Statement stmt=con.createStatement();
			ResultSet rs = stmt.executeQuery("show databases");
			while(rs.next()){
				dbnames.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dbnames;
	}

}
