package com.yash.ycmscore.service;

import java.util.List;

import com.yash.ycmscore.model.User;

/**
 * this is the service interface for User related operations such as create,
 * List users, update and delete a user
 * 
 * @author ishan.juneja Functionalities provided 1.) add a user 2.) delete a
 *         user 3.) update a user 4.) list users
 */
public interface UserService {

	/**
	 * this method will be used to pass a user to the userDAO
	 * 
	 * @author ishan.juneja
	 * @param user
	 *            to be saved in the database
	 * @return true if user added successfully or false if their is some error
	 *         saving the object
	 */
	public boolean add(User user);

	/**
	 * this method will be used to pass the user to the userDAO to be updated in
	 * the database
	 * 
	 * @author ishan.juneja
	 * @param user
	 *            to be updated
	 * @return true if update is successful or false if the update is
	 *         unsuccessful
	 */
	public boolean update(User user);

	/**
	 * this method will be used to pass the id of the user to be deleted to the
	 * userDAO
	 * 
	 * @author ishan.juneja
	 * @param id
	 *            of the user to be deleted
	 * @return true if delete operation is successful and false if delete
	 *         operation is unsuccessful
	 */
	public boolean delete(int id);

	/**
	 * this method will return a list of all the users in the database
	 * 
	 * @author ishan.juneja
	 * @return a list of all the users in the database
	 */
	public List<User> list();

}
