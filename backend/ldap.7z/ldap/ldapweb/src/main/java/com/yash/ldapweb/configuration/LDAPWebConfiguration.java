package com.yash.ldapweb.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.yash.ldapcore.ldapconfiguration.LdapConfiguration;

@Configuration
@EnableWebMvc
@ComponentScan("com.yash")
public class LDAPWebConfiguration extends LdapConfiguration{

}
