package com.yash.ldapcore.ldapconfiguration;

import java.util.Hashtable;
import javax.naming.Context;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * This class will be the LDAP configuration in the application.
 * It reads the properties from the ldap.properties file placed in the resources folder on classpath.
 * This class has a method which initailizes the hashtable variables with context properties :
 * 1.INITIAL_CONTEXT_FACTORY
 * 2.SECURITY_AUTHENTICATION
 * 3.PROVIDER_URL
 * 4.SECURITY_PRINCIPAL
 * 5.SECURITY_CREDENTIALS
 * 
 * Date - 04/06/2018
 * 
 * @Configuration Annotating a class with the @Configuration indicates that the
 *                class can be used by the Spring IoC container as a source of
 *                bean definitions.
 * @ComponentScan annotation is used with @Configuration to tell Spring the
 *                packages to scan for annotated components.
 * @PropertySource is used to externalize your configuration to a properties
 *                 file
 * 
 * @author minerva.shrivastava
 *
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages="com.yash")
@PropertySource(value="classpath:ldap.properties")
public class LdapConfiguration {

	/**
	 * This will be used to read the properties file 
	 * In future this could be used to read the profile option from the arguments
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private Environment environment;
	
	/**
	 * This method initializes the specified properties above in the Hashtable
	 * @param email is set into the property SECURITY_PRINCIPAL of Context
	 * @param password is set into the property SECURITY_CREDENTIALS of Context
	 * @return Hashtable with properties and values
	 */
	public Hashtable<String, Object> intializeHashTableEnvironment(String email, String password) {
		
		Hashtable<String, Object> hashTableEnv = new Hashtable<String, Object>();
		
		hashTableEnv.put(Context.INITIAL_CONTEXT_FACTORY, environment.getProperty("LDAP_INITIAL_CONTEXT_FACTORY"));
		hashTableEnv.put(Context.SECURITY_AUTHENTICATION, environment.getProperty("LDAP_SECURITY_AUTHENTICATION"));
		hashTableEnv.put(Context.PROVIDER_URL, environment.getProperty("LDAP_PROVIDER_URL"));
		hashTableEnv.put(Context.SECURITY_PRINCIPAL, email);
		hashTableEnv.put(Context.SECURITY_CREDENTIALS, password);
		
		return hashTableEnv;

	}
}
