package com.yash.ldapcore.serviceimpl;

import java.util.Hashtable;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.yash.ldapcore.ldapconfiguration.LdapConfiguration;
import com.yash.ldapcore.service.UserService;

/**
 * 
 * @author minerva.shrivastava
 *
 */
@Service
public class UserServiceImpl implements UserService {
	
	private LdapConfiguration conf = new LdapConfiguration();
	private SearchResult searchResult;
	
	public boolean authenticateUser(String email, String password) {
	
		Hashtable<String, Object> environment = conf.intializeHashTableEnvironment(email, password);
		String accountToLookup = "sAMAccountName=" + email.substring(0, email.indexOf("@"));
		InitialDirContext ctx = null;
		try {
			ctx = new InitialDirContext(environment);
			SearchControls searchControls = new SearchControls();
			searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			
			//LDAP_SEARCH_BASE :Domain (com.yash)
			NamingEnumeration<SearchResult> results = ctx.search("DC=yash,DC=com", accountToLookup,
					searchControls);

			if (results.hasMoreElements()) {
				searchResult = results.nextElement();
				System.out.println(searchResult);
				return true;
			}
			
		} catch (NamingException e) {
			e.printStackTrace();
		}
		finally {
			try {
				ctx.close();
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}

		return false;		

	}

}
