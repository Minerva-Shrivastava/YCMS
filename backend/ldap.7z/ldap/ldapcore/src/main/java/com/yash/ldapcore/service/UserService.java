package com.yash.ldapcore.service;

/**
 * This is the service interface for user related operations 
 * Operation performed : User Authentication
 * @author minerva.shrivastava
 *
 */
public interface UserService {

	public boolean authenticateUser(String email,String password);
}
