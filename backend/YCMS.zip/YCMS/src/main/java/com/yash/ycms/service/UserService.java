package com.yash.ycms.service;

import java.util.Hashtable;

/**
 * this is the service interface for User related operations such as create,
 * List users, update and delete a user
 * 
 * @author Mayank Functionalities provided 1.) intializeHashTableVariables a
 *         user 2.) userAuthentication
 */
public interface UserService {

	/**
	 * This method will initialize all the properties and return them
	 * 
	 * @author mayank
	 * @param email
	 *            - yash email
	 * @param password
	 *            -yash password
	 * @return enviormentForContext - to initialize the context
	 */
	public Hashtable<String, Object> intializeHashTableVariables(String email, String password);

	/**
	 * this method will authenticate the user on the basis of details entered by
	 * user
	 * 
	 * @author mayank
	 * @param email
	 *            - yash email entered by user
	 * @param password
	 *            -yash password entered by user
	 * @return true if context is made i.e details are correct . false- if
	 *         exception is encountered while making context i.e details are
	 *         incorrect
	 */
	public boolean userAuthentication(String email, String password);

	public long calculateTime();

}
