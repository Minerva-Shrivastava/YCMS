package com.yash.ycms.serviceimpl;

import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.InitialDirContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.yash.ycms.service.UserService;

/**
 * this class will authenticate the user on the basis of details provided by him
 *
 * Date - 05/04/2018
 * 
 * @author Mayank
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 * @PropertySource is used to externalize your configuration to a properties
 *                 file
 */
@Service
@PropertySource("classpath:resources/ldapconfig.properties")
public class UserServiceImpl implements UserService {

	/**
	 * this is the enviornment bean needed here in service
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private Environment environment;
	/**
	 * this is to take environmentForContext
	 * 
	 */
	private Hashtable<String, Object> environmentForContext;

	/**
	 * This method will initialize all the properties and return them
	 * 
	 * @author mayank
	 * @param email
	 *            - yash email
	 * @param password
	 *            -yash password
	 * @return enviormentForContext - to initialize the context
	 */
	public Hashtable<String, Object> intializeHashTableVariables(String email, String password) {

		environmentForContext = new Hashtable<String, Object>();
		environmentForContext.put(Context.INITIAL_CONTEXT_FACTORY,
				environment.getProperty("LDAP_INITIAL_CONTEXT_FACTORY"));
		environmentForContext.put(Context.SECURITY_AUTHENTICATION,
				environment.getProperty("LDAP_SECURITY_AUTHENTICATION"));
		environmentForContext.put(Context.PROVIDER_URL, environment.getProperty("LDAP_PROVIDER_URL"));
		environmentForContext.put(Context.SECURITY_PRINCIPAL, email);// username
		environmentForContext.put(Context.SECURITY_CREDENTIALS, password);// passowrd
		return environmentForContext;

	}

	/**
	 * this method will authenticate the user on the basis of details entered by
	 * user
	 * 
	 * @author mayank
	 * @param email
	 *            - yash email entered by user
	 * @param password
	 *            -yash password entered by user
	 * @return true if context is made i.e details are correct . false- if
	 *         exception is encountered while making context i.e details are
	 *         incorrect
	 */
	public boolean userAuthentication(String email, String password) {

		try {
			InitialDirContext ctx = new InitialDirContext(intializeHashTableVariables(email, password));
			System.out.println("context  " + ctx);

			return true;

		} catch (NamingException e) {
			return false;

		}

	}

	public long calculateTime() {

		long timeAtAccountLocked = System.currentTimeMillis();
	    System.out.println("locked at "+timeAtAccountLocked);
		long timeAtAccountShouldRelease = timeAtAccountLocked + 1800000;
		System.out.println("to unlock at "+timeAtAccountShouldRelease);
	
		
		return timeAtAccountShouldRelease;
	}

}
