package com.yash.ycms.controller;

import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ycms.service.UserService;

/**
 * this is the Controller that will handle the requests for the User related
 * resources
 * 
 * @author Mayank
 * @RestCOntroller is to make the controller as rest api i.e to make this as api
 */

@RestController()
public class UserController {

	/**
	 * this variable is to track no. of attempts done by user for login
	 */

	private static int attempts = 3;

	private static long timeAtAccountShouldRelease = 0;

	/**
	 * this is to inject userservice here in controller
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	UserService userService;

	/**
	 * this method is to redirect user with wrong credential on same login page
	 * with error message
	 * 
	 * @return
	 */
	@RequestMapping(value = "user/login", method = RequestMethod.GET)
	public String userAuthentication() {

		if (attempts == 0) {

			long minutes = TimeUnit.MILLISECONDS.toMinutes(timeAtAccountShouldRelease);
			System.out.println("can try after  " + minutes + "minutes");
			if (timeAtAccountShouldRelease < System.currentTimeMillis()) {
				attempts = 3;
			}

		}
		if (attempts > 0) {
			boolean valid = userService.userAuthentication("mayank", "gautam");
			if (valid) {
				attempts = 3;
				return "success";
			} else {
				attempts--;
				timeAtAccountShouldRelease = userService.calculateTime();
				System.out.println("Attempt Left :" + attempts);
				return "Failed";
			}
		}
		return "You have Exceeded the number of attempts ...sorry buddy!";

	}
}
