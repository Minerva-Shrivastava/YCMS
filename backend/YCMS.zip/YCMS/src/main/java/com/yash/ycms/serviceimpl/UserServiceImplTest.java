package com.yash.ycms.serviceimpl;

import static org.junit.Assert.*;

import org.junit.Test;

public class UserServiceImplTest {

	@Test
	public void testUserAuthentication() {
		fail("Not yet implemented");
	}

}
