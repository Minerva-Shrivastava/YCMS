package com.yash.ldapweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ldapcore.model.User;
import com.yash.ldapcore.service.UserService;

/**
 * This controller will handle the requests for customer related resources.
 * 
 * @author minerva.shrivastava
 *
 */
@RestController
public class LdapController {

	/**
	 * The userService bean which is autowired
	 * 
	 *  @author minerva.shrivastava
	 */
	@Autowired
	private UserService userService;
	
	/**
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping(value="/user/auth",method=RequestMethod.POST)
	public Object authenticateUser(@RequestBody User user)
	{	
		System.out.println("Controller working");
		System.out.println(user.getEmail());
		return userService.authenticateUser(user.getEmail(), user.getPassword());
	}
}
