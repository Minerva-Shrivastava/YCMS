package com.yash.ldapweb.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ldapcore.model.User;

@RestController
public class UserController {
	
	private static final String EMAIL_URL="http://localhost:8080//index.jsp?";

	@RequestMapping(value="/generateLink" , method=RequestMethod.POST)
	public String generateLink(@RequestBody User user) {
		
		return "<a href="+EMAIL_URL+user.getEmail()+">Click Me</a>";
	}
}
