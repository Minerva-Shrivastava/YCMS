package com.yash.ldapcore.serviceimpl;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.yash.ldapcore.service.UserService;

/**
 * 
 * @author minerva.shrivastava
 *
 */
@PropertySource(value="classpath:ldap.properties")
@Service
public class UserServiceImpl implements UserService {
	
	private SearchResult searchResult;
	Map<Object, List<Object>> mapofAttributesWithValues;
	
	/**
	 * This will be used to read the properties file 
	 * In future this could be used to read the profile option from the arguments
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private Environment environment;
	
	/**
	 * This method initializes the specified properties above in the Hashtable
	 * @param email is set into the property SECURITY_PRINCIPAL of Context
	 * @param password is set into the property SECURITY_CREDENTIALS of Context
	 * @return Hashtable with properties and values
	 */
	private Hashtable<String, Object> intializeHashTableEnvironment(String email, String password) {
		
		Hashtable<String, Object> hashTableEnv = new Hashtable<String, Object>();
		
		hashTableEnv.put(Context.INITIAL_CONTEXT_FACTORY, environment.getProperty("LDAP_INITIAL_CONTEXT_FACTORY"));
		hashTableEnv.put(Context.SECURITY_AUTHENTICATION, environment.getProperty("LDAP_SECURITY_AUTHENTICATION"));
		hashTableEnv.put(Context.PROVIDER_URL, environment.getProperty("LDAP_PROVIDER_URL"));
		hashTableEnv.put(Context.SECURITY_PRINCIPAL, email);
		hashTableEnv.put(Context.SECURITY_CREDENTIALS, password);
		
		return hashTableEnv;

	}
	
	public Object authenticateUser(String email, String password) {
		Hashtable<String, Object> environment = intializeHashTableEnvironment(email, password);
		String accountToLookup = "sAMAccountName=" + email.substring(0, email.indexOf("@"));
		InitialDirContext ctx = null;
		try {
			ctx = new InitialDirContext(environment);
			SearchControls searchControls = new SearchControls();
			searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			//LDAP_SEARCH_BASE :Domain (com.yash)
			NamingEnumeration<SearchResult> results = ctx.search("DC=yash,DC=com", accountToLookup,
					searchControls);
			if (results.hasMoreElements()) {
				searchResult = results.nextElement();
				System.out.println(searchResult);
				return getAttributesMap();
			}
		} catch (NamingException e) {
			e.printStackTrace();
		}
		finally {
			try {
				ctx.close();
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}
		return null;		
	}
	
	private Map<Object, List<Object>> getAttributesMap() {
		Attributes attributes = searchResult.getAttributes();
		System.out.println("Attributes :"+attributes);
		if (attributes == null) {
			System.out.println("No attributes To Display");
			return null;
		}
		try {
			NamingEnumeration namingEnumeration = attributes.getAll();
			while (namingEnumeration.hasMore()) {
				Attribute attribute = (Attribute) namingEnumeration.next();
				System.out.println("Attribute :"+attribute);
				List<Object> listOfAttributeValues = new ArrayList<Object>();
				NamingEnumeration e = attribute.getAll();
				while (e.hasMore()) {
					System.out.println("elements in attribute :"+e.next());
					listOfAttributeValues.add(e.next());
				}
				mapofAttributesWithValues.put(attribute.getID(), listOfAttributeValues);
			}
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return mapofAttributesWithValues;
	}

}
