package com.yash.ldapcore.ldapconfiguration;

import java.util.Hashtable;
import javax.naming.Context;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * This class will be the LDAP configuration in the application.
 * It reads the properties from the ldap.properties file placed in the resources folder on classpath.
 * This class has a method which initailizes the hashtable variables with context properties :
 * 1.INITIAL_CONTEXT_FACTORY
 * 2.SECURITY_AUTHENTICATION
 * 3.PROVIDER_URL
 * 4.SECURITY_PRINCIPAL
 * 5.SECURITY_CREDENTIALS
 * 
 * Date - 04/06/2018
 * 
 * @Configuration Annotating a class with the @Configuration indicates that the
 *                class can be used by the Spring IoC container as a source of
 *                bean definitions.
 * @ComponentScan annotation is used with @Configuration to tell Spring the
 *                packages to scan for annotated components.
 * @PropertySource is used to externalize your configuration to a properties
 *                 file
 * 
 * @author minerva.shrivastava
 *
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages="com.yash")

public class LdapConfiguration {

	
}
