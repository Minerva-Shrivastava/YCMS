package com.yash.categoryweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.categorycore.model.Category;
import com.yash.categorycore.service.CategoryService;


/**
 * this is the Controller that will handle the requests for the Category related resources
 * 
 * Date - 
 * 
 * @author minerva.shrivastava
 *
 */
@RestController
public class CategoryController {

	/**
	 * this will be the bean, which will give the methods of CategoryService to
	 * the controller
	 * 
	 * @author minerva.shrivastava
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired 
	private CategoryService categoryService;
	
	
	/**
	 * This controller method is to add the categories
	 * @param question obtained from the body of the request
	 */
	@RequestMapping(value="/category", method=RequestMethod.POST)
	public String addQuestions(@RequestBody Category category){
		 boolean result = categoryService.addCategory(category);
		 if(result)
			 return "Category added successfully";
		 else
			 return "error";
	}
	
	/**
	 * This controller method retrieves the list of all Category 
	 * @return List of Categories 
	 */
	@RequestMapping(value="/categories", method=RequestMethod.GET)
	public List<Category> getAllCategories(){
		return categoryService.listAllCategories();
		
	}
}
