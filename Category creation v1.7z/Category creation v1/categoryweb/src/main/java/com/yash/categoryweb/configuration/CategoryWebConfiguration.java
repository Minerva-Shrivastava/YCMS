package com.yash.categoryweb.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * this class will contain the web configuration for the YCMS application
 * 
 * @author minerva.shrivastava
 * @Configuration Annotating a class with the @Configuration indicates that the
 *                class can be used by the Spring IoC container as a source of
 *                bean definitions.
 * @ComponentScan annotation is used with @Configuration to tell Spring the
 *                packages to scan for annotated components.
 * @EnableWebMvc is equivalent to <mvc:annotation-driven /> in XML. It enables
 *               support for @Controller-annotated classes that
 *               use @RequestMapping to map incoming requests to a certain
 *               method.
 */
@Configuration
@EnableWebMvc
@ComponentScan("com.yash")
public class CategoryWebConfiguration extends WebMvcConfigurerAdapter {


		/**
		 * this method will add cross origin request handling to the application and
		 * allow requests coming from http://localhost:4200 change localhost to
		 * application server's ip and 4200 to application server's port
		 * 
		 * @author minerva.shrivastava
		 * @param Cross
		 *            origin registry
		 */
		/*@Override
		public void addCorsMappings(CorsRegistry registry) {
			registry.addMapping("/ycmsweb/**").allowedOrigins("http://localhost:4200")
					.allowedMethods("POST", "PUT", "GET", "OPTIONS", "DELETE").allowedHeaders("x-requested-with , Authorization")
					.maxAge(3600);
		}*/
}


