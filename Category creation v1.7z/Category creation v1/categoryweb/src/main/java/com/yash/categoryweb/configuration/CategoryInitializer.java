package com.yash.categoryweb.configuration;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**
 * this class will be the Web initializer of the application. it will configure
 * the application on the basis of the configurations provided in the
 * application
 * 
 * @author minerva.shrivastava
 *
 */
public class CategoryInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {


	/**
	 * this method will give the list of all the configuration classes passed to
	 * it
	 * 
	 * @author minerva.shrivastava
	 */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] { CategoryWebConfiguration.class };
	}

	/**
	 * this method will give the servlets configuration classes for the
	 * application
	 * 
	 * @author ishan.juneja
	 */
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return null;
	}

	/**
	 * this method will set the servlet mappings in the application
	 * 
	 * @author ishan.juneja
	 */
	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

}
