package com.yash.categorycore.dao;

import java.util.List;

import com.yash.categorycore.model.Category;

/**
 * this is the interface for all database related operations for Category such as
 * Add/List
 * 
 * Date - 
 * 
 * @author minerva.shrivastava  Functionalities provided:- 1.) add a category 2.) list a category
 */
public interface CategoryDAO {

	/**
	 * this method will be used to add a Category to the database
	 * @param category to add
	 * @return true if Category is added successfully otherwise false in case of some error
	 * @author minerva.shrivastava
	 */
	public boolean insert(Category category);
	
	/**
	 * This method retrieves the list of all Categories
	 * @return List of all the categories
	 * @author minerva.shrivastava
	 */
	public List<Category> listAllCategories();
}
