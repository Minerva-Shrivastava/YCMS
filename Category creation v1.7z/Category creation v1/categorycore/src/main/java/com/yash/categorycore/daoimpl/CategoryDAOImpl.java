package com.yash.categorycore.daoimpl;

import java.util.LinkedList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlMapFactoryBean;
import org.springframework.stereotype.Repository;

import com.yash.categorycore.dao.CategoryDAO;
import com.yash.categorycore.model.Category;

/**
 * this is the implementation class for CategoryDAO interface 
 * 
 * Date - 
 * 
 * @author minerva.shrivastava
 * @Repository annotation is used in your DAO layer and annotates classes that
 *             perform Database tasks
 */
@Repository
public class CategoryDAOImpl implements CategoryDAO{

	/**
	 * The session factory variable which is autowired
	 * this will give a session
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private SessionFactory sessionFactory;
	
	/**
	 * session will be obtained from session factory
	 */
	private Session session;
	
	/**
	 * This method inserts the Category into the database through the hibernate 
	 * saveOrUpdate method in a transaction which is rolledback in case of an exception  
	 */
	/**
	 * this method will be used to add a Category to the database
	 * @param category to be saved in the database
	 * @return true if Category is added successfully otherwise false in case of some error
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean insert(Category category) {
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			session.saveOrUpdate(category);
			transaction.commit();
			return true;
		} catch (HibernateException ex) {
			if (transaction != null) {
				System.out.println("Transaction Rollback");
				transaction.rollback();
			}
			ex.printStackTrace();
			return false;
		} finally {
			session.close();
		}
	}

	/**
	 * This method retrieves the list of all Categories from the database
	 * @return List of all the categories
	 * 
	 * @author minerva.shrivastava
	 */
	public List<Category> listAllCategories() {
		
		List<Category> categories = new LinkedList<Category>();
		
		Session session = sessionFactory.openSession();
		System.out.println("session :"+session);

		Transaction transaction = null;

		try {
			
			transaction = session.getTransaction();
			transaction.begin();
			Query query = session.createQuery("from Category");
			categories = query.list();
			System.out.println(categories);
			for (Category category : categories) {
				System.out.println(category.getTitle());
				System.out.println(category.getDescription());
			}
			
			transaction.commit();

		}catch (HibernateException ex) {

			if (transaction != null) {
				transaction.rollback();
			}
			ex.printStackTrace();

		} finally {
			session.close();
		}
		
		return categories;
	}

}
