package com.yash.categorycore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * this is the category POJO. 
 * this will be used as a data traveler between the different layers of the application 
 * this will also work as an entity for database(categories)
 * 
 * Date - 
 * 
 * @author minerva.shrivastava
 * @Entity Every persistent POJO class is an entity and is declared using
 *         the @Entity annotation
 * @Table annotation allows you to specify the details of the table that will be
 *        used to persist the entity in the database.
 */
@Entity
@Table(name = "categories")
public class Category {

	/**
	 * this will be the id of the catogory
	 * 
	 * @Id declares the identifier property of this entity
	 * @GeneratedValue can be used to define the identifier generation strategy
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	
	/**
	 * this will be the title of the category
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "title")
	private String title;
	
	/**
	 * this will be the description of the category
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "description")
	private String description;
	
	/**
	 * this will be the parent category of the category
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	private String parent;
	
	/**
	 * this will be the status of the category
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	private String status;
	
	/**
	 * a default constructor for Category class.
	 */
	public Category() {
	}

	/**
	 * a parameterized constructor required for the conversion to JSON
	 */
	public Category(int id, String title, String description, String parent, String status) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.parent = parent;
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getParent() {
		return parent;
	}
	public void setParent(String parent) {
		this.parent = parent;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
