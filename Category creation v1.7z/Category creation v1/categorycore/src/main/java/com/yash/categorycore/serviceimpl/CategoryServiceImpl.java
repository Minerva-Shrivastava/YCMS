package com.yash.categorycore.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.categorycore.dao.CategoryDAO;
import com.yash.categorycore.model.Category;
import com.yash.categorycore.service.CategoryService;

/**
 * this is the implementation of the Category Service interface
 *
 * Date - 
 * 
 * @author minerva.shrivastava
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 */
@Service
public class CategoryServiceImpl implements CategoryService{


	/**
	 * The services call the DAO layer functionalities through this variable
	 */
	@Autowired
	private CategoryDAO categoryDAO;
	
	/**
	 * this method will be used to pass category to the categoryDAO
	 * @param category to be saved in the database 
	 * @return true if Category is added successfully otherwise false in case of some error
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean addCategory(Category category) {
		return categoryDAO.insert(category);
	}

	/**
	 * This method retrieves the list of all Categories
	 * @return List of Categories
	 * 
	 *  @author minerva.shrivastava
	 */
	public List<Category> listAllCategories() {
		return categoryDAO.listAllCategories();
	}

}
