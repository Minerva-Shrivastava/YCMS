package com.yash.categorycore.service;

import java.util.List;
import com.yash.categorycore.model.Category;

/**
 * this is the service interface for Category related services such as create,
 * List categories
 * 
 * @author minerva.shrivastava Functionalities provided 1.) add a category 2.) list category
 *
 */
public interface CategoryService {

	/**
	 * This method provides the service of inserting the category
	 * 
	 * @author minerva.shrivastava 
	 * @param category to be saved in the database
	 * @return true if category is added successfully or false if their is some error
	 *         
	 * @author minerva.shrivastava
	 */
	public boolean addCategory(Category category);
	
	/**
	 * This method retrieves the list of all Categories
	 * @return List of Categories
	 * 
	 *  @author minerva.shrivastava
	 */
	public List<Category> listAllCategories();
}
